/*
Samplecode for:
Wemos D1 mini with HC-SR04 Ultrasonic sensor as switch, Wifi and Mqtt Publish and Subscribe message 
To install the Wemos D1 mini board
  - Add the following 3rd party board manager under "File -> Preferences -> Additional Boards Manager URLs":
       http://arduino.esp8266.com/stable/package_esp8266com_index.json
  - Open the "Tools -> Board -> Board Manager" and click install for the ESP8266"
  - Select your ESP8266 in "Tools -> Board"

23-03-2019 Marco Rudolph
*/

#include <ESP8266WiFi.h>      // https://github.com/esp8266/Arduino/tree/master/libraries/ESP8266WiFi
#include <PubSubClient.h>     // Mqtt pubsublient by knolleary -  https://github.com/knolleary/pubsubclient/blob/master/examples/mqtt_esp8266/mqtt_esp8266.ino
#include <NewPing.h>          // NewPing library by Tim Eckel -  


#define ECHO_PIN D6    //Define the HC-SR04 triger on pin D6 or GPIO12
#define TRIGGER_PIN D4 //Define the HC-SR04 echo on pin D5 or GPIO2
#define LED D2         //Define the relay signal on pin D2 or GPIO4
#define MAX_DISTANCE 200

NewPing sonar(TRIGGER_PIN, ECHO_PIN, MAX_DISTANCE);  //

// Update these with values suitable for your network.
// WiFi network info.
char ssid[] = "your SSID";
char wifiPassword[] = "your passwd";

//Free MQTT Broker HiveMQ
const char *mqtt_server = "broker.hivemq.com";

unsigned long lastMillis = 0;

WiFiClient espClient;
PubSubClient client(espClient);
long lastMsg = 0;
char msg[50];
int value = 0;

void setup_wifi()
{

   delay(10);
   // We start by connecting to a WiFi network
   Serial.println();
   Serial.print("Connecting to ");
   Serial.println(ssid);

   WiFi.begin(ssid, wifiPassword);

   while (WiFi.status() != WL_CONNECTED)
   {
      delay(500);
      Serial.print(".");
   }

   randomSeed(micros());

   Serial.println("");
   Serial.println("WiFi connected");
   Serial.println("IP address: ");
   Serial.println(WiFi.localIP());
}

void callback(char *topic, byte *payload, unsigned int length)
{
   Serial.print("Message arrived [");
   Serial.print(topic);
   Serial.print("] ");
   for (int i = 0; i < length; i++)
   {
      Serial.print((char)payload[i]);
   }
   Serial.println();

   // Switch on the LED if an 1 was received as first character
   if ((char)payload[0] == '1')
   {
      digitalWrite(LED, LOW); // Turn the LED on (Note that LOW is the voltage level
                              // but actually the LED is on; this is because
                              // it is active low on the ESP-01)
   }
   else
   {
      digitalWrite(LED, HIGH); // Turn the LED off by making the voltage HIGH
   }
}

void reconnect()
{
   // Loop until we're reconnected
   while (!client.connected())
   {
      Serial.print("Attempting MQTT connection...");
      // Create a random client ID
      String clientId = "ESP8266Client-";
      clientId += String(random(0xffff), HEX);
      // Attempt to connect
      if (client.connect(clientId.c_str()))
      {
         Serial.println("connected");
         // Once connected, publish an announcement...
         client.publish("outBike", "Measurement started");
         // ... and resubscribe
         client.subscribe("inBike");
      }
      else
      {
         Serial.print("failed, rc=");
         Serial.print(client.state());
         Serial.println(" try again in 5 seconds");
         // Wait 5 seconds before retrying
         delay(5000);
      }
   }
}

void LedOn() //Start the LedOn subroutine
{
   digitalWrite(LED, HIGH); //turn on the LedOn
   //delay (15000);                        //wait 15 seconds
   //digitalWrite(LED, LOW);              //turn off the LedOn
}

void LedOff() //Start the LedOff subroutine
{
   digitalWrite(LED, LOW); //turn on the LedOn
   //delay (15000);                        //wait 15 seconds
   //digitalWrite(LED, HIGH);              //turn off the LedOn
}

void setup()
{
   Serial.begin(9600);           //Start the serial monitor
   pinMode(TRIGGER_PIN, OUTPUT); //set the TRIGGER_PIN to output
   pinMode(ECHO_PIN, INPUT);     //set the ECHO_PIN to input
   pinMode(LED, OUTPUT);         //set the LED on pin 9 to output
   setup_wifi();
   client.setServer(mqtt_server, 1883);
   client.setCallback(callback);
}

void loop()
{

   if (!client.connected())
   {
      reconnect();
   }
   client.loop();

   long now = millis();
   if (now - lastMsg > 5000)

   {
      unsigned int distance = sonar.ping_cm();
      Serial.print("Distance: ");
      Serial.print(distance);
      Serial.println(" cm");
      delay(5000); //delay half a second

      if (distance < 13)   // Bike wheel split the ultrasonic beam 
      {
         LedOn(); //execute the LedOn subroutine below
         client.publish("outBike", "1");        // publish on topic outBike value 1
         //Serial.print("Publish message: ");   
         //Serial.println(msg);
      }
      else 
      {
         LedOff();       //execute the LedOff subroutine below
         client.publish("outBike", "0");        // publish on topic outBike value 0
      }
      {
         //lastMsg = now;
         //++value;
         //snprintf(msg, 50, "hello world #%ld", value);
         //Serial.print("Publish message: ");
         //Serial.println(msg);
         //client.publish("outBike", msg);
      }
   }

}


